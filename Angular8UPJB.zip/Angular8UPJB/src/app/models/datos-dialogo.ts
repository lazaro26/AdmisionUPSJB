export class DatosDialogo {
    titulo: string;
    id: number;
    dato: any;
}
