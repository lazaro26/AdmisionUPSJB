export interface IResponse {
    response: string;
}
