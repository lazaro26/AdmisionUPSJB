export interface ISedes {
    codsed: string;
    descripcion :string;
}