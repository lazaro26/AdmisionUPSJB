export interface IEspecialidades {
    CODESP: string;
    DESCRIPCION :string;
}