export interface IAsistencia {
    Id_postulante: number;
    fecreg :Date;
}