export interface IPostulante {
    id_postulante: number;
    numdoc: string;
    codesp: string;
    codsed: string;
   
}

