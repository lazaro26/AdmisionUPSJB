export interface ILogin {
    usuario: string;
    password: string;
}
